package in.ongrid.quizPortal.controller;
import in.ongrid.quizPortal.dao.BaseResponce;
import in.ongrid.quizPortal.entities.User;
import in.ongrid.quizPortal.model.dto.*;
import in.ongrid.quizPortal.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping(path = "/user")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping(path = "/")
    public BaseResponce<SignUpUserResponse> signUp(@RequestBody SignUpUserRequest request) {
        SignUpUserResponse signUpResponse = userService.signUp(request);
        return new BaseResponce<>(HttpStatus.OK.value(), "Success", signUpResponse);
    }


    @GetMapping(path = "/")
    public BaseResponce<User> GetProfile(@RequestHeader("Authorization") String token) {
        if (StringUtils.isBlank(token)) throw new AccessDeniedException("token cannot be null.");
        User user = userService.getProfile(token);
        return new BaseResponce<>(HttpStatus.OK.value(), "Success", user);
    }


    @PostMapping(path = "/update")
    public BaseResponce<UpdateUser> updateProfile(@RequestBody UpdateUser request, @RequestHeader("Authorization") String token) {
        if (StringUtils.isBlank(token)) throw new AccessDeniedException("token cannot be null.");
        UpdateUser updateProfileResponse = userService.updateProfile(token, request);
        return new BaseResponce<>(HttpStatus.OK.value(), "Success", updateProfileResponse);
    }


    @PostMapping(path = "/login")
    public BaseResponce<LoginResponse> Login(@RequestBody LoginRequest request) {
        LoginResponse user = userService.Login(request);
        return new BaseResponce<>(HttpStatus.OK.value(), "Success", user);
    }

    @PostMapping(path = "/logout")
    public BaseResponce<String> Logout(@RequestHeader("Authorization") String token) {
        if (StringUtils.isBlank(token)) throw new AccessDeniedException("token cannot be null.");
        userService.Logout(token);
        return new BaseResponce<>(HttpStatus.OK.value(), "Success", "User successfully logout.");

    }


}
