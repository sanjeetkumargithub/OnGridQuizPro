import SignUpComponent from "./SignUp"
    
export {
    SignUpComponent
}