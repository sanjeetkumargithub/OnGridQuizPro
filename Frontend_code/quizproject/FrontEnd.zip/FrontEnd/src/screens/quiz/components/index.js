import QuizPageComponent from "./Quiz";

import AnswerDialog from "./AnswerDialog";
export { QuizPageComponent, AnswerDialog };
