import { QuizContainer as Quiz } from "./containers";
export default Quiz;


