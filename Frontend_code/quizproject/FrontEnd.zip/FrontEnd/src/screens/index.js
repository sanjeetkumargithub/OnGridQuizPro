import Home from "./home";
import Login from "./login";
import Profile from "./profile";
import SignUp from "./signup";
import Quiz from "./quiz";
export { Home, Login, Profile, SignUp, Quiz };
