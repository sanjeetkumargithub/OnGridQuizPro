import React from 'react'

import { Header, Footer } from '../../shared'
import {
    Route,
    BrowserRouter,
    Routes
} from 'react-router-dom'
import { publicRoutes } from '../../navigation/routes';



const PublicLayout = ({ }) => {
    return (
        <>
            <Header />
          
                <BrowserRouter>
                    <Routes>
                
                        {publicRoutes && publicRoutes.map((item, index) => <Route key={index} exact path={item.path} element={item.component} />)}
                      
                    </Routes>
                </BrowserRouter>
           
            <Footer />
        </>
    )
}

export default PublicLayout