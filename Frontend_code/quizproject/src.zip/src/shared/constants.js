const gender = [
  {
    label: "Male",
    value: 0,
  },
  {
    label: "Female",
    value: 1,
  },
  {
    label: "Others",
    value: 2,
  },
];

const choice = [
  {
    label: "True",
    value: "true",
  },
  {
    label: "False",
    value: "false",
  },
];

export { gender, choice };
