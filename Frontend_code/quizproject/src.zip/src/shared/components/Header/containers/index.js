import React, { Component } from 'react'
import HeaderComponent from '../components';

class HeaderContainer extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <HeaderComponent />
        )

    }
}

export default HeaderContainer