import React, { Component } from "react";
import { LoginComponent } from "../components";

class LoginContainer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      data: {},
    };
  }
  handleChange = (value, key) => {
    this.setState({
      data: { ...this.state.data, [key]: value },
    });
  };

  render() {
    console.log(this.state.data);
    return (
      <LoginComponent data={this.state.data} handleChange={this.handleChange} />
    );
  }
}

export default LoginContainer;
