import { LoginContainer as Login } from './containers'

export default Login