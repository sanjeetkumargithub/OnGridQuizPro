import React from "react";
import { Grid, Paper, Avatar } from "@material-ui/core";

import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { Link, Button, Input } from "../../../shared";
const LoginComponent = ({ data, handleChange }) => {
  const paperStyle = {
    padding: 20,
    height: "47vh",
    width: 320,
    margin: "20px auto",
  };
  const avatarStyle = { backgroundColor: "#1bbd7e" };
  const btnstyle = { margin: "8px 0" };
  return (
    <Grid padding={20} margin={20}>
      <Paper elevation={10} style={paperStyle}>
        <Grid align="center">
          <Avatar sx={{ m: 1, bgcolor: "secondary.main" }} style={avatarStyle}>
            <LockOutlinedIcon />
          </Avatar>

          <h2>Login In</h2>
        </Grid>

        <Input
          type="text"
          placeholder="Enter  Email Id"
          label="Email id"
          value={data.email}
          handleChange={(value) => handleChange(value, "email")}
        />
        <Input
          type="password"
          placeholder="Enter  password"
          label="password"
          value={data.password}
          handleChange={(value) => handleChange(value, "password")}
        />

        <Button name="Login In" />

        <Grid container justifyContent="center">
          <Link body="Don't have an account? Sign Up" link="/signup" />
        </Grid>
      </Paper>
    </Grid>
  );
};

export default LoginComponent;
