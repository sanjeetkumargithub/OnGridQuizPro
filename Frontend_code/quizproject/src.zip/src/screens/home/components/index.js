import HomeComponent from './Home'

export {
    HomeComponent
}