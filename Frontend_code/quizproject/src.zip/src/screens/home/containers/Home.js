import React, { Component } from 'react'
import { HomeComponent } from '../components';

class HomeContainer extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <HomeComponent />
        )

    }
}

export default HomeContainer