import React, { Component } from "react";
import { SignUpComponent } from "../components";
import axios from "axios";
import base_url from "../../../utils/api";
class SignUpContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: {},
    };
  }
  handleChange = (value, key) => {
    this.setState({
      data: { ...this.state.data, [key]: value },
    });
  };

  //
  handleForm = () => {





  //   //e.preventDefault();
  //   console.log(this.state.data);
  //   const url = `${base_url}/user`;
  //   fetch(url, {
  //     method: "POST",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //     body: JSON.stringify(this.state.data),
  //   })
  //     .then((response) => response.json())
  //     .then((response) => {
  //       this.setState({ signUp: true });
  //     })
  //     .catch(() =>
  //       console.log("Can’t access " + url + " response. Blocked by browser")
  //     );
  // };
 
    axios.post(`${base_url}/user`, this.state.data, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(this.state.data),
    })
      .then((response) => {
        console.log(response);
        console.log("successssssssssssssss");
      })
      .catch((error) => {
        console.log(error);
        console.log("errorrrrrrrrrrrrrrrrrrrrrrrr");
      });
       

  
  };

  //

  render() {
    console.log(this.state.data);

    return (
      <SignUpComponent
        data={this.state.data}
        handleChange={this.handleChange}
        handleForm={this.handleForm}
      />
    );
  }
}

export default SignUpContainer;
