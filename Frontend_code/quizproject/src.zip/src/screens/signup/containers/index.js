import SignUpContainer from './SignUp'

export {
    SignUpContainer
}