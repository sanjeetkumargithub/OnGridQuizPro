import {SignUpContainer as SignUp} from "./containers"
export default SignUp