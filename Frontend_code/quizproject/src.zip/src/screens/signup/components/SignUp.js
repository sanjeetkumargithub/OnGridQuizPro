import React from "react";
import { Grid, Paper, Avatar, Typography, TextField } from "@material-ui/core";

import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import {
  Link,
  Input,
  Button,
  CustomRadioButton,
  DateTime,
} from "../../../shared";
import { FormControl } from "@mui/material";
import { gender } from "../../../shared/constants";

const SignUpComponent = ({ data, handleChange, handleForm }) => {
  const paperStyle = {
    padding: "20px 60px",
    width: 400,
    margin: "20px auto",
    height: "68vh",
  };
  const headerStyle = { margin: 0 };
  const avatarStyle = { backgroundColor: "#1bbd7e" };
  //const marginTop = { marginTop: 5 }
  const btnstyle = { margin: "8px 0" };
  return (
    <Grid container height="38vh">
      <Paper elevation={20} style={paperStyle}>
        <Grid align="center">
          <Avatar sx={{ m: 1, bgcolor: "secondary.main" }} style={avatarStyle}>
            <LockOutlinedIcon />
          </Avatar>

          <h2 style={headerStyle}>Sign Up</h2>
          <Typography variant="caption" gutterBottom>
            Please fill this form to create an account !
          </Typography>
        </Grid>
        <FormControl>
          <Input
            type="text"
            placeholder="Enter  Name"
            label="Name"
            value={data.name}
            handleChange={(value) => handleChange(value, "name")}
          />
          <Input
            type="text"
            placeholder="Enter  Email Id"
            label="Email id"
            value={data.email}
            handleChange={(value) => handleChange(value, "email")}
          />

          <Input
            type="number"
            placeholder="Enter  Mobile Number"
            label="Mobile Number"
            value={data.mobile}
            handleChange={(value) => handleChange(value, "mobile")}
          />

          <Input
            type="password"
            placeholder="Enter passowrd"
            label="password"
            value={data.password}
            handleChange={(value) => handleChange(value, "password")}
          />

          {/* <Input
            type="password"
            placeholder="Enter Confirm Password "
            label="Confirm password"
            value={data.confirmPassword}
            handleChange={(value) => handleChange(value, "confirmPassword")}
          /> */}

          <CustomRadioButton options={gender} label="Gender"
          
          value={data.gender}
          handleChange={(value) => handleChange(value, "gender")}
          />
          <DateTime
            value={data.DateOfBirth}
            handleChange={(value) => handleChange(value, "DateOfBirth")}
          />

          <Button name="Sign Up" handleForm={handleForm} />
          <Grid>
            <Grid container justifyContent="center">
              <Link
                body="if you have all ready acount? LoginKnow"
                link="/login"
              />
            </Grid>
          </Grid>
        </FormControl>
      </Paper>
    </Grid>
  );
};

export default SignUpComponent;
