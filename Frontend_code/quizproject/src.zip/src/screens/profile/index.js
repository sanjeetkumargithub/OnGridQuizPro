import {ProfileComponent as Profile} from "./containers"
export default Profile