import QuizComponent  from "./Quiz"
export{
    QuizComponent
}