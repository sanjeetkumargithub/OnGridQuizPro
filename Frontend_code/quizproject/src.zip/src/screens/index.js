import Home from "./home";
import Login from "./login";
import Profile from "./profile";
import SignUp from "./signup";
import Quiz from "./quiz";
import Score from "./score";
export{
    Home,
    Login,
    Profile,
    SignUp,
    Quiz,
    Score
   

}