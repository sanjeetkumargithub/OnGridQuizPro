import React, { Component } from 'react'
import { ScoreComponent } from '../components';

class ScoreContainer extends Component {

    constructor(props) {
        super(props)
    }

    render() {
        return (
            <ScoreComponent />
        )

    }
}

export default ScoreContainer