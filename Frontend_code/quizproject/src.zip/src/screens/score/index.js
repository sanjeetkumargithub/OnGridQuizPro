import { ScoreContainer as Score } from './containers'

export default Score