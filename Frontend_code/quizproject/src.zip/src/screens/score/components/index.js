import ScoreComponent from './Score'

export {
    ScoreComponent
}