package in.ongrid.quizPortal.model;

public enum Gender {
    M,
    F,
    O
}
