package in.ongrid.quizPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
