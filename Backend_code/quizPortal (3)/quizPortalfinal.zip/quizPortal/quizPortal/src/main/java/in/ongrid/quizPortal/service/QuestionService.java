package in.ongrid.quizPortal.service;
import in.ongrid.quizPortal.entities.Question;
import in.ongrid.quizPortal.model.dto.CreateUpdateQuestionRequest;
import in.ongrid.quizPortal.model.dto.QuizScore;

import java.util.List;

public interface QuestionService {

 void createQuestion(CreateUpdateQuestionRequest request, int quizId);

    List<Question> getQuestion(int quizId ,String token);

   QuizScore submitQuiz(List<CreateUpdateQuestionRequest> request ,String token);
}
