package in.ongrid.quizPortal.controller;

import in.ongrid.quizPortal.dao.BaseResponce;
import in.ongrid.quizPortal.dao.UserSessionDao;
import in.ongrid.quizPortal.entities.User;
import in.ongrid.quizPortal.entities.UserSession;
import in.ongrid.quizPortal.model.dto.CreateUpdateUserRequest;
import in.ongrid.quizPortal.model.dto.SignUpLoginResponce;
import in.ongrid.quizPortal.model.dto.UpdateUser;
import in.ongrid.quizPortal.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping(path = "/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private UserSessionDao userSessionDao;

    // User create account
    @PostMapping
    public  BaseResponce<SignUpLoginResponce> createUser(@RequestBody CreateUpdateUserRequest request )  {
        SignUpLoginResponce user=userService.createUser(request);
        return  new BaseResponce<>(HttpStatus.OK.value(), "Success" , user);
            }

    // Update user account
     @PostMapping(path= "/update")
         public BaseResponce<UpdateUser> updateUser(@RequestBody UpdateUser request, @RequestHeader("Authorization") String token)  {
            if(StringUtils.isBlank(token))  throw new IllegalArgumentException("User is not authorized to update account.");
                    UpdateUser user=  userService.updateUser(token,request);
                    return  new BaseResponce<>(HttpStatus.OK.value(), "Success" , user);
         }

    // user Login account
    @PostMapping(path="/login")  // create account ki tarah change karna ?
    public BaseResponce<SignUpLoginResponce> userLogin(@RequestBody CreateUpdateUserRequest request)  {
        SignUpLoginResponce user= userService.userLogin(request);
        return  new BaseResponce<>(HttpStatus.OK.value(), "Success" , user);
    }

    // user logout
    @PostMapping(path = "/logout")
    public  BaseResponce< String> UserLogout( @RequestHeader("Authorization") String token){
        if(StringUtils.isBlank(token))  throw new IllegalArgumentException("User not Authorized to Logged out.cc");
            userService.UserLogout(token);
            return  new BaseResponce<>(HttpStatus.OK.value(), "Success","User successfully logout." );

        }



}
