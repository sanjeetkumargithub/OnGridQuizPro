package in.ongrid.quizPortal.service;
import in.ongrid.quizPortal.entities.Quiz;
import in.ongrid.quizPortal.model.dto.CreateUpdateQuizRequest;
import java.util.List;

public interface QuizService {
    Quiz createQuiz(CreateUpdateQuizRequest quiz);

    List<Quiz> getQuiz();


}
