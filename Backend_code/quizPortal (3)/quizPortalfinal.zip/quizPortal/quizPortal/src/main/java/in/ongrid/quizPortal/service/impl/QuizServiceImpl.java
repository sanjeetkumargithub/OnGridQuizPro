package in.ongrid.quizPortal.service.impl;
import in.ongrid.quizPortal.dao.QuizDao;
import in.ongrid.quizPortal.entities.Quiz;
import in.ongrid.quizPortal.model.dto.CreateUpdateQuizRequest;
import in.ongrid.quizPortal.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class QuizServiceImpl  implements QuizService {
        @Autowired
         QuizDao quizDao;

        // Create Quiz
        @Override
        public Quiz createQuiz(CreateUpdateQuizRequest quiz) {
                if(quiz.getTitle().length()==0) throw new IllegalArgumentException("Quiz title must be required.");
                Quiz newQuiz=new Quiz();
                newQuiz.setTitle(quiz.getTitle());
                LocalDateTime dt=LocalDateTime.now();

               return quizDao.save(newQuiz);
        }

    //  Get All quizzes
        @Override
        public List<Quiz> getQuiz() {
            return quizDao.findAll();

        }




}
