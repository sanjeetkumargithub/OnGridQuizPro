package in.ongrid.quizPortal.service;

import in.ongrid.quizPortal.entities.User;
import in.ongrid.quizPortal.entities.UserSession;
import in.ongrid.quizPortal.model.dto.CreateUpdateUserRequest;
import in.ongrid.quizPortal.model.dto.SignUpLoginResponce;
import in.ongrid.quizPortal.model.dto.UpdateUser;

import java.util.List;

public interface UserService {



    SignUpLoginResponce createUser(CreateUpdateUserRequest request) ;

    UpdateUser updateUser(String token, UpdateUser request) ;

    SignUpLoginResponce userLogin(CreateUpdateUserRequest request);

    void UserLogout(String token);
}
